<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php conform_logged_in(); ?>
<?php include("include/layout/header_about.php"); ?>

<!--=====================================================================-->
<?php $client_id=$_GET["client_id"];?>
<?php
		if(isset($_POST['buy_pro'])){
		
		$requried_fields = array("division_id","district_id","address","detail","price","requirement","contact","type");
		validation_presence($requried_fields);
		
		$fields_with_max_length=array(contact=>15);
		validation_length($fields_with_max_length);
		
	/********************************************************************************************************/
	/*	$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		
		if (file_exists($target_file)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
	
		if ($_FILES["fileToUpload"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
	
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
	
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
			
		} else {
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		} else {
			echo "Sorry, there was an error uploading your file.";
			}
		}*/
/*************************************************************************************************************/

		if(empty($errors)){
			$id=$_POST["client_id"];;
			$division_id=(int)($_POST["division_id"]);
			$district_id=(int)($_POST["district_id"]);
			$address=mysqli_pom($_POST["address"]);
			$detail=mysqli_pom($_POST["detail"]);
			$price=(int) $_POST["price"];
			$requirement=mysqli_pom($_POST["requirement"]);
			$contact=mysqli_pom($_POST["contact"]);
			$type=mysqli_pom ($_POST["type"]);
			$visible=(int) $_POST["visible"];
			//$check=$_POST["fileToUpload"];
			
		//	$image = file_get_contents ($_FILES['fileToUpload']['tmp_name']);
		//	$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			
		/*	if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}
			echo $check;*/
			
			$query="INSERT INTO properties_info 
					(client_id,division_id,district_id,address,
					detail,price,requirement,contact,type,visible)
					VALUES('{$id}',{$division_id},{$district_id},'{$address}',
					'{$detail}',{$price},'{$requirement}','{$contact}','{$type}',{$visible});";
			
			$result=mysqli_query($connection,$query);
	
			if($result)
			{
				$_SESSION["message"]="Information Inserted Succesfully..";
				redirection_page(sprintf("user_profile.php?id=%s",$id));
			}
			else{
				$_SESSION["message"]="Information does not inserted";
				redirection_page(sprintf("user_profile.php?id=%s",$id));
			}	
		}
		}
		else{
			
			}	
?>


<!--==============================content================================-->

<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Giving Addvertise of Buying/Renting Properties </h2>
        <div class="wrap">
        	<img src="images/page5-img1.jpg" alt="" class="img-border img-indent">
            <div class="extra-wrap">
            	<p class="color-1 p6">For giving addvertise for buying/renting,
									fill up this form with valid property informations.</p>
           		<p>All informations should be valid otherwise we will sue you.</p>
            </div>
        </div>
        <div class="grid_8">
	   
        <h2 class="top-1 p3">Registration form</h2>
        <form id="form" action="buy_property.php" method="post" enctype="multipart/form-data" >
			<input type="hidden" name="client_id" value="<?php echo htmlentities($client_id); ?>">
           <!-- <label><strong>Image:</strong><input type="file" name="fileToUpload" id="fileToUpload" value=""></label>-->
            <label><strong>Division:</strong>
			<select name="division_id">
			<?php	$division= select_division();?>
			<?php while($division_row=mysqli_fetch_assoc($division)){?>
			<option value="<?php echo ($division_row["division_id"]); ?>">
				<?php echo htmlentities($division_row["division_name"]); ?>
			</option>
			<?php } ?>
			<?php mysqli_free_result($division);?>
			</select>
			</label>
			<label><strong>District:</strong>
			<select name="district_id">
			<?php	$district= select_district();?>
			<?php while($district_row=mysqli_fetch_assoc($district)){?>
			<option value="<?php echo ($district_row["district_id"]); ?>">
				<?php echo htmlentities($district_row["district_name"]); ?>
			</option>
			<?php } ?>
			<?php mysqli_free_result($district);?>
			</select>
			</label>
			
			
			<label><strong>Address:</strong><textarea name="address"></textarea></label>
			<label><strong>Detail:</strong><textarea name="detail"></textarea></label>
			<label><strong>Price:</strong><input type="text" name="price" value=""></label>
			<label><strong>Requirement:</strong><textarea name="requirement"></textarea></label>
			<label><strong>Contact:</strong><input type="text" name="contact" value=""></label>
		    <label><strong>Type:</strong></label>
			<input type="radio" name="type" value="buy" /> Buy<br/>
			<input type="radio" name="type" value="rent" /> Rent
			
			<label><strong>Visiblity:</strong></label>
			<input type="radio" name="visible" value="1" />Visible<br/>
			<input type="radio" name="visible" value="0" />Not Visible
            
			<div class="btns">
			<!--<a href="#" class="button" onClick="document.getElementById('form').submit()">Submit</a>-->
			<input type="submit" class="button" name="buy_pro" value="Submit"/>
			</div>
        </form> 
      </div>
      </div>
	  <br/><br/>
      <div class="grid_4">
        <div class="left-1">
            <h2 class="p3">Our contacts</h2>
            <dl>
                <dt class="color-1 p2"><strong>Rajshahi University,<br>Rajshahi.</strong></dt>
                <dd><span>Freephone:</span>+881XXXXXXXXX</dd>
                <dd><span>Telephone:</span>+8802XXXXXX</dd>
                <dd><span>E-mail:</span><a href="#" class="link">mail@live.com</a></dd>
            </dl>
        </div>
      </div>
      <div class="clear"></div>
	  
	   <br/>
	    <?php echo message(); ?>
	    <?php echo form_errors($errors);?>
    
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
 
<?php include("include/layout/footer_buy.php");?>