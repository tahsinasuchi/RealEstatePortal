<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>


<?php include("include/header.php")?>
	<div>
	<br/>

	<?php	$data= address_data();?>
	<?php while($data_row=mysqli_fetch_assoc($data)){?>
	Name :<?php echo htmlentities($data_row["name"]); ?><br/>
	Nick Name :<?php echo htmlentities($data_row["nick_name"]); ?><br/>
	Phone No.:<?php echo htmlentities($data_row["phone"]); ?><br/>
	Address:<?php echo htmlentities($data_row["address"]); ?><br/>
	Website :<?php echo htmlentities($data_row["website"]); ?><br/>
	BirthDay<br/>
	<?php echo htmlentities(.$data_row["day"]."/".$data_row["month"]."/".$data_row["year"]); ?><br/>
	<?php }
		 mysqli_free_result($data);?><hr/>
	</div>

<?php include("include/footer.php")?>