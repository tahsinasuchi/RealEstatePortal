<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->

<section id="content">
    <div class="container_12">	
      <div class="grid_8">
	  
        <h2 class="top-1 p3">Properties Information</h2>
        <p>Here, you get all properties information...</p>
		
		<table >
		<tr><th>Property ID</th><th>Image</th><th>Price</th><th>Address</th><th>More</th><th>Visibility</th></tr><br/>
		<?php	$properties=  properties_db();?>
		<?php while($properties_row=mysqli_fetch_assoc($properties)){?>
		
		<tr>
		<td><?php echo htmlentities($properties_row[id]); ?></td>
		<td><img src="<?php echo htmlentities($properties_row["image"]); ?>" alt="" class="img-border img-indent"></td>
		<td><?php echo htmlentities($properties_row["price"]); ?></td>
		<td><?php echo htmlentities($properties_row["contact"]); ?></td>
		<td><p class="p5"><a href="property_all_info.php?property_id=<?php echo urlencode($properties_row[id]); ?>" class="button">Details</a>
		</p></td>
		<td><p>
			<a href="update_property_id_admin.php?property_id=<?php echo urlencode($properties_row[id]); ?>" class="button">Update</a>
		</p></td>
		</tr><br/>
		<?php }
		 mysqli_free_result($properties);?>
		</table>
        </div>
		<br/><br/><br/>
    
      </div>
    <div class="clear"></div>
</section> 
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>