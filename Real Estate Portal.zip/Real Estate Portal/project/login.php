<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php include("include/layout/header_login.php"); ?>

<!--============================================================-->
<?php
	if(isset($_POST['registration'])){
		
		$requried_fields = array("first_name", "last_name", "user_name", "client_id", "email", "gender", "address", "contact", "password", "repassword");
		validation_presence($requried_fields);
		
		$fields_with_max_length=array("first_name"=>30, "last_name"=>30, "user_name"=>60);
		validation_length($fields_with_max_length);
		
		if(empty($errors)){
			$first_name=mysqli_pom($_POST["first_name"]);
			$last_name=mysqli_pom($_POST["last_name"]);
			$user_name=mysqli_pom($_POST["user_name"]);
			$client_id=mysqli_pom($_POST["client_id"]);
			$email=mysqli_pom($_POST["email"]);
			$gender=(int) $_POST["gender"];
			$address=mysqli_pom($_POST["address"]);
			$contact=mysqli_pom($_POST["contact"]);
			$password=password_encrypt($_POST["password"]);
			$repassword=password_encrypt($_POST["repassword"]);
			
			$conform_password=conform_password($password,$repassword);
			
			$query="INSERT INTO client_info (first_name, last_name, user_name, client_id, email, gender, address, contact, password,type)
			VALUES('{$first_name}','{$last_name}','{$user_name}','{$client_id}', '{$email}', {$gender}, '{$address}', '{$contact}', '{$conform_password}','client');";
			
			$result=mysqli_query($connection,$query);
	
			if($result)
			{
				$_SESSION["message"]="Registration complete..";
				redirection_page("login.php");
			}
			else{
				$_SESSION["message"]="Registration does not complete..";
				redirection_page("login.php");
			}	
		}
		}
		else{
			
			}	
?>

<!--============================================================-->

<?php
	$email="";
	if(isset($_POST['log'])){
		
		$requried_fields = array("email", "password");
		validation_presence($requried_fields);
		
		if(empty($errors)){
			$email=$_POST["email"];
			$password=$_POST["password"];
			$found_client=attempt_login($email,$password);
			
			if($found_client)
			{
				$_SESSION["client_id"]=$found_client["client_id"];
				$_SESSION["user_name"]=$found_client["user_name"];
				$_SESSION["email"]=$found_client["email"];
				$_SESSION["type"]=$found_client["type"];
				$_SESSION["message"]="Login Successfuly";
				
				if($found_client["type"]=='admin'){
					redirection_page("admin_profile.php");
				}else{
					redirection_page("user_profile.php");
				}
			    
			}
			else{
				$_SESSION["message"]="Username/Password does not match..";
			}	
			}
		}
		else{
	
	}
?>
<!--==============================content================================-->
<section id="content">
    <div class="container_12">	 
      <div class="grid_8">
	   <div class="clear"></div><br/>
	    <?php echo message();
			  echo form_errors($errors);?>
       
	   <h2 class="top-1 p3">Registration form</h2>
        <form id="form" action="login.php" method="post" >
            <label><strong>First Name:</strong><input type="text" name="first_name" value=""></label>
			<label><strong>Last Name:</strong><input type="text" name="last_name" value=""></label>
			<label><strong>User Name:</strong><input type="text" name="user_name" value=""></label>
            <label><strong>User ID:</strong><input type="text" name="client_id" value=""></label>
			<label><strong>E-mail:</strong><input type="email" name="email" value=""></label>
		    <label><strong>Gender:</strong></label>
			<input type="radio" name="gender" value="male" /> Male<br/>
			<input type="radio" name="gender" value="female" /> Female
            <label><strong>Address:</strong><textarea name="address" value=""></textarea></label>
			<label><strong>Contact:</strong><input type="text" name="contact" value=""></label>
			<label><strong>Password:</strong><input type="password" name="password" value=""></label>
			<label><strong>Rewrite Password:</strong><input type="password" name="repassword" value=""></label>
			
			<input type="submit" name="registration" value="Submit" class="sbtn" >	
            
        </form> 
		
      </div>
      <div class="grid_4">
        <div class="left-1">
            <h2 class="top-1 p3">Sign in</h2>
            <form id="form-1" class="form-1 bot-2" action="login.php" method="post" >
               <label><strong>E-mail:</strong><input type="email" name="email" value="<?php echo htmlentities($email)?>"></label>   
               <label><strong>Password:</strong><input type="password" name="password" value=""></label> 
               <!--<input type="submit" class="button" name="log" value="Submit"/>-->
			   <input type="submit" name="log" value="Login" class="submit" >	
			  
			  <div class="clear"></div>
            </form>
            <h2 class="p3">Our contacts</h2>
            <dl>
                <dt class="color-1 p2"><strong>Rajshahi University,<br>Rajshahi.</strong></dt>
                <dd><span>Freephone:</span>+881XXXXXXXXX</dd>
                <dd><span>Telephone:</span>+8802XXXXXX</dd>
                <dd><span>E-mail:</span><a href="#" class="link">mail@live.com</a></dd>
            </dl>
        </div>
      </div>
	  
      <div class="clear"></div><br/>
	   
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
   
<?php include("include/layout/footer_buy.php");?>