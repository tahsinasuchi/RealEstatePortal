<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->
 <section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Client's Information </h2>
        <p class="p2">You can view client's information..</p>
		
		<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>User Name</th>
			<th>Email</th>
			<th>Address</th>
			<th>Contact</th>
			<th>More</th>
		</tr>
		<br/>
		<?php	
			$client_id=$_GET["client_id"];
			$client= client_data($client_id);
			while($client_set=mysqli_fetch_assoc($client)){
		?>
		<tr>
			<td><?php echo htmlentities($client_set["first_name"]); ?></td>
			<td><?php echo htmlentities($client_set["last_name"]); ?></td>
			<td><?php echo htmlentities($client_set["user_name"]); ?></td>
			<td><?php echo htmlentities($client_set["email"]); ?></td>
			<td><?php echo htmlentities($client_set["address"]); ?></td>
			<td><?php echo htmlentities($client_set["contact"]); ?></td>
			<td><p>
			<a href="delete_client.php?client_id=<?php echo urlencode($client_set[id]); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
			</p></td>
		</tr>
		<?php }
				mysqli_free_result($client);?>
		</table>
        
	<h2 class="top-1 p3">Client's Properties Information</h2>
        <p class="p2">You can view client's properties information..</p>		
		
		<table>
		<tr>
			<th>Image</th>
			<th>Address</th>
			<th>Contact</th>
			<th>Type</th>
			<th>Visibelity</th>
			<th>Read More</th>
			<th>More</th>
		</tr>
		<br/>
		<?php
			$client_properties_info= client_properties($client_id);
			while($client_row=mysqli_fetch_assoc($client_properties_info)){
		?>
		<tr>
			<td><img src="<?php echo htmlentities($client_row["image"]); ?>" alt="" class="img-border img-indent"></td>
			<td><?php echo htmlentities($client_row["address"].",".$client_row["division_name"].",".$client_row["district_name"]); ?></td>
			<td><?php echo htmlentities($client_row["contact"]); ?></td>
			<td><?php echo htmlentities($client_row["type"]); ?></td>
			<td><?php echo htmlentities($client_row["visible"]); ?></td>
			<td><p>
			<a href="client_property_admin.php?property_id=<?php echo urlencode($client_row[id]); ?>" class="button">Details</a>
			</p></td>
			<td><p>
			<a href="delete_property_admin.php?property_id=<?php echo urlencode($client_row[id]); ?>&&client_id=<?php echo urlencode($client_id); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
			</p></td>
		</tr>
		<?php }
			mysqli_free_result($client_properties_info);?>
		</table>	
	 </div>
    </div>
    <div class="clear"></div>
</section> 
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>