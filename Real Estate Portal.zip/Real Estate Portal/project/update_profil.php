<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php conform_logged_in(); ?>
<?php include("include/layout/header_about.php"); ?>

<!--============================================================-->
<?php
	$client_id=$_GET["client_id"];
	//$client_id_data= client_data($client_id);
?>
<?php
	if(isset($_POST['update'])){
		
		$requried_fields = array("first_name", "last_name", "user_name", "email", "address", "contact", "password");
		validation_presence($requried_fields);
		
		$fields_with_max_length=array("first_name"=>30, "last_name"=>30, "user_name"=>60);
		validation_length($fields_with_max_length);
		
		if(empty($errors)){
			$first_name=mysqli_pom($_POST["first_name"]);
			$last_name=mysqli_pom($_POST["last_name"]);
			$user_name=mysqli_pom($_POST["user_name"]);
			$email=mysqli_pom($_POST["email"]);
			$address=mysqli_pom($_POST["address"]);
			$contact=mysqli_pom($_POST["contact"]);
			$password=password_encrypt($_POST["password"]);
			//$id=$client_id_data["client_id"];
			
			$query="UPDATE client_info SET 
					first_name = '{$first_name}',last_name = '{$last_name}',user_name = '{$user_name}',
					email = '{$email}',address = '{$address}',contact = '{$contact}',
					password = '{$password}' WHERE client_id = '{$client_id}' LIMIT 1";
			
			$result=mysqli_query($connection,$query);
	
			if($result && mysqli_affected_rows($connection) >= 0)
			{
				$_SESSION["message"]="Update Successfully..";
				redirection_page("user_profile.php");
			}
			else{
				$_SESSION["message"]="Update does not complete..";
				redirection_page("profile.php");
			}	
		}
		}
		else{
			
			}	
?>

<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Welcome <?php echo	htmlentities($_SESSION["user_name"]);?>!</h2>
        <p class="p2">You can view and update your profile..</p>
		
		<h2 class="p4">Your Information:</h2>
		<?php echo message(); 
			  echo form_errors($errors);
			  ?>
		
		<div class="wrap block-1">
			<?php	
				$client_set= client_data($client_id);
				//while($client_set=mysqli_fetch_assoc($client_data)){
			?>
			
            <form id="form" action="update_profile.php" method="post" >
            
			<label>
				<strong>First Name:</strong>
					<input type="text" name="first_name" value="<?php echo htmlentities($client_set["first_name"]); ?>">
			</label>
			<label>
				<strong>Last Name:</strong>
					<input type="text" name="last_name" value="<?php echo htmlentities($client_set["last_name"]); ?>">
			</label>
			<label>
				<strong>User Name:</strong>
					<input type="text" name="user_name" value="<?php echo htmlentities($client_set["user_name"]); ?>">
			</label>
			<label>
				<strong>E-mail:</strong>
					<input type="email" name="email" value="<?php echo htmlentities($client_set["email"]); ?>">
			</label>
			<label>
				<strong>Address:</strong>
					<input type="text" name="address" value="<?php echo htmlentities($client_set["address"]); ?>">
			</label>
			<label>
				<strong>Contact:</strong>
					<input type="text" name="contact" value="<?php echo htmlentities($client_set["contact"]); ?>">
			</label>
			<label>
				<strong>Password:</strong>
					<input type="password" name="password" value="">
			</label>
			<?php// }
				//mysqli_free_result($client_data);?>
			<input type="submit" name="update" value="Update" class="sbtn-1" >	
            
        </form> 
        </div>
      </div>
      
      <div class="clear"></div>
    </div>  
</section> 
</div>    

<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>