<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php conform_logged_in(); ?>
<?php include("include/layout/header_about.php"); ?>

<!--==============================content================================-->
<?php $select_property=$_GET["property_id"]; ?>
<?php
		if(isset($_POST['update'])){
		
		$requried_fields = array("image","division_id","district_id","address","detail","price","requirement","contact","type");
		validation_presence($requried_fields);
		
		$fields_with_max_length=array(contact=>15);
		validation_length($fields_with_max_length);
		
		if(1){
			//$id=(int)($_POST["id"]);
			$image       =mysqli_pom($_POST["image"]);
			$division_id =(int)($_POST["division_id"]);
			$district_id =(int)($_POST["district_id"]);
			$address     =mysqli_pom($_POST["address"]);
			$detail      =mysqli_pom($_POST["detail"]);
			$price       =(int) $_POST["price"];
			$requirement =mysqli_pom($_POST["requirement"]);
			$contact     =mysqli_pom($_POST["contact"]);
			$type        =mysqli_pom ($_POST["type"]);
			$visible     =(int) $_POST["visible"];
			$id          =$_POST["id"];

			 echo $query=sprintf("UPDATE  properties_info SET  
					image = '%s',
				    address = '%s', 
					detail = '%s',
					price = %s, requirement = '%s', contact = '%s',
					type = '%s', visible = %s
					WHERE  id = %s LIMIT 1",
					$image,$address,
					$detail,$price,
					$requirement,$contact,
					$type,$visible,$id);
			
			$result=mysqli_query($connection,$query);
	
				if($result)
				{
					$_SESSION["message"]="Successfuly Subject Updated..";
					redirection_page("user_profile.php");
				}
				else{
					$message="Subject Does Not Updated..";
					//redirection_page("update_property.php");
				}	
			}
}	else{
		
	}
?>

<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3"><?php echo	htmlentities($_SESSION["user_name"]);?>'s Properties!</h2>
		
		<hr/>
        <h4 class="p4">Update Your Properties:</h2>
       
			
        <div class="extra-wrap">
        <p class="color-1 p6">
		 <?php 
			$property_update= client_properties_update( $select_property);
			while($property_row = mysqli_fetch_assoc($property_update)){
			?>
			 <form id="form" action="update_property.php?property=<?php echo urlencode($property_row["id"]); ?>" method="post" >
           
     		<input type="hidden" name="id" value="<?php echo htmlentities($property_row["id"]); ?>">
			
			<label>
			<img src="<?php echo htmlentities($property_row["image"]); ?>" alt="" class="img-border img-indent">
			</label>
			<input type="hidden" name="address" value="<?php echo htmlentities($property_row["id"]); ?>">
		
		   <label>
				<strong>Address:</strong>
					<input type="text" name="address" value="<?php echo htmlentities($property_row["address"]); ?>">
			</label>
			<!--<label><strong>Division:</strong><br/>
			<select name="division_id">
			<?php//	$division= select_division();?>
			<?php //while($division_row=mysqli_fetch_assoc($division)){?>
			<option value="<?php// echo ($division_row["division_id"]); ?>">
				<?php //echo htmlentities($division_row["division_name"]); ?>
			</option>
			<?php// } 
				//mysqli_free_result($division);?>
			</select>
			</label>
		<label><strong>District:</strong>
			<select name="district_id">
			<?php	//$district= select_district();?>
			<?php //while($district_row=mysqli_fetch_assoc($district)){?>
			<option value="<?php //echo ($district_row["district_id"]); ?>">
				<?php //echo htmlentities($district_row["district_name"]); ?>
			</option>
			<?php //} 
				//mysqli_free_result($district);?>
			</select>-->
			</label>
			<label>
				<strong>Details:</strong>
					<input type="text" name="detail" value="<?php echo htmlentities($property_row["detail"]); ?>">
			</label>
			<label>
				<strong>Price:</strong>
					<input type="text" name="price" value="<?php echo htmlentities($property_row[price]); ?>">
			</label>
			<label>
				<strong>Requirement:</strong>
					<input type="text" name="requirement" value="<?php echo htmlentities($property_row["requirement"]); ?>">
			</label>
			<label>
				<strong>Contact:</strong>
					<input type="text" name="contact" value="<?php echo htmlentities($property_row["contact"]); ?>">
			</label>
			
			<label><strong>Type:</strong></label>
			<input type="radio" name="type" value="buy" 
			<?php if($property_row[type]==buy){ echo "checked";} ?>/> Buy<br/>
			<input type="radio" name="type" value="rent"
			<?php if($property_row[type]==rent){ echo "checked";} ?>	/> Rent
			
			<label><strong>Visiblity:</strong></label>
			<input type="radio" name="visible" value="1" 
			<?php if($property_row[visible]==1){ echo "checked";} ?>/>Visible<br/>
			<input type="radio" name="visible" value="0" 
			<?php if($property_row[visible]==0){ echo "checked";} ?>/>Not Visible<br/><br/>
			
			<?php }
				mysqli_free_result($property_update);?>
			<input type="submit" name="update" value="Update" class="sbtn-1" >	
            
        </form> 

		</div>
        </div>
      <div class="clear"></div>
    </div>  
</section>    

<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>