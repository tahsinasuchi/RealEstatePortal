<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>


<?php 
		$id=$_GET["client_id"];
		$query="DELETE FROM client_info WHERE id = {$id} LIMIT 1 ;";
			
		$result=mysqli_query($connection,$query);
	
		if($result)
			{
				$_SESSION["message"]="Successfuly client Deleted..";
				redirection_page("client_info.php");
			}
		else{
				$message="Client Does Not Deleted..";
				redirection_page("client_info.php");
			}
			
?>