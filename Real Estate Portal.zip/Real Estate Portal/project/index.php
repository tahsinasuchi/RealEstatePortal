<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_index.php"); ?>
<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Welcome !</h2>
        <p class="p2">This is the Real Estate Portal. One of the biggest Real Estate portal in our county.</p>
        <p class="line-1">You can buy or rent properties as you wish. Or you can give Addvertise about your 
						  property for buying or selling.</p>
<!--=======================================Search========================================================================-->
<section id="content">
		<div class="container_12">	
		  <div class="grid_8"><br/><br/>
<?php
	if(isset($_POST['search'])){
		
		$division_id=(int)($_POST["division_id"]);
		$district_id=(int)($_POST["district_id"]);
		$price=(int) $_POST["price"];
		$type=mysqli_pom ($_POST["type"]);
			
		$query="SELECT * FROM properties_info WHERE
				division_id LIKE {$division_id} OR
				district_id LIKE {$district_id} OR
				price LIKE {$price} and type='{$type}' and visible=1";
			
		$result=mysqli_query($connection,$query);
	
		if($result)
		{
			//$_SESSION["search_result"]=$result;
			while($buy_row=mysqli_fetch_assoc($result)){
?>
			<div class="wrap">
			<img src="<?php echo htmlentities($buy_row["image"]); ?>" alt="" class="img-border img-indent">
			<div class="extra-wrap">
			<p class="color-1 p6">
			Address:<?php echo htmlentities($buy_row["address"]); ?><br/>
			Details:<?php echo htmlentities($buy_row["detail"]); ?><br/>
			Price:<?php echo htmlentities($buy_row["price"]); ?><br/>
			Type:<?php echo htmlentities($buy_row["type"]); ?><br/>
			<p class="p5"><a href="buy_view.php?id=<?php echo urlencode($buy_row["id"]); ?>" class="button">Read More</a></p>
			</div>
			</div>
<?php		 }
		 mysqli_free_result($result);
		//redirection_page("buying.php");
		}
		else{
			$_SESSION["message"]="Cant find the property";
			redirection_page("index.php");
			}
	}
?>

	</div>
 </section> 
<!--===============================================================================================================-->
		
        <h2 class="p4">Buyers. Renters. Proprietors. Agents.</h2>
        <div class="wrap block-1">
            <div>
                <img src="images/page1-img1.jpg" alt="" class="img-border">
                <h3>Buying</h3>
                <p>You can visit our site for buying properties.Here you get some best properties.</p>
                <a href="buying.php" class="button">More</a>
            </div>
            <div class="last">
                <img src="images/page1-img3.jpg" alt="" class="img-border">
                <h3>Renting</h3>
                <p>You can visit our site for renting properties.Here you get some best properties.</p>
                <a href="renting.php" class="button">More</a>
            </div>
        </div>
      </div>
<!--===================================Search Box===================================================-->
 
      <div class="grid_4">
        <div class="left-1">
            <h2 class="top-1 p3">Find your Property</h2>
            <form id="form-1" action="index.php" method="post" class="form-1 bot-1">
                <div class="select-1">
                   <label>Division:</label>
					<select name="division_id">
					<?php	$division= select_division();?>
					<?php while($division_row=mysqli_fetch_assoc($division)){?>
					<option value="<?php echo ($division_row["division_id"]); ?>">
					<?php echo htmlentities($division_row["division_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($division);?>
					</select>  
                </div>
				<div class="select-1">
					<label>District:</label>
					<select name="district_id">
					<?php	$district= select_district();?>
					<?php while($district_row=mysqli_fetch_assoc($district)){?>
					<option value="<?php echo ($district_row["district_id"]); ?>">
					<?php echo htmlentities($district_row["district_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($district);?>
					</select>
			   </div>
			   <div>
					<label>Type</label>
                    <input type="text" name="type" value="" /><!--onBlur="if(this.value=='') this.value='Buy/Rent'" onFocus="if(this.value =='Buy/Rent' ) this.value=''"  />-->
               </div><br/>
               <div >
					<!--<a href="#" class="button" onClick="document.getElementById('form').submit()">Submit</a>-->
					<input type="submit" class="submit" name="search" value="Search" />
				</div>
				<div class="clear"></div>
            </form>
            <h2 class="p3">Find our office</h2>
            <img src="images/page1-img4.png" alt="">
			<div class="lists">
                <ul class="list-1">
                    <li><a href="#">Dhaka</a></li>
                    <li><a href="#">Rajshahi</a></li>
                    <li><a href="#">Sylhet</a></li>
                </ul>
                <ul class="list-1 last">
                    <li><a href="#">Chittagong</a></li>
                    <li><a href="#">Borisal</a></li>
                    <li><a href="#">Khulna</a></li>
                </ul>
            </div>
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
  
 <?php include("include/layout/footer_buy.php");?>