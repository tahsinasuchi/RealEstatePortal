<?php
	$host="localhost";
	$user="root";
	$pass="";
	$db="real";
	$connection=mysqli_connect($host,$user,$pass,$db);
	
	if(mysqli_connect_errno()){
		die("Database connection error ".
			mysqli_connect_error."(".mysqli_connect_error.")"
		);
	}
?>