<!--==============================footer=================================-->
    <footer>
        <p>� 2015 Real Estate</p>
    </footer>	    
<script>
	Cufon.now();
</script>
</body>
</html>

<?php
		if(isset($connection)){
			mysqli_close($connection);
		}
?>
