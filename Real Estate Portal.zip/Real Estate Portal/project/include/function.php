<?php
	function redirection_page($new_location){
		header("Location:  " . $new_location);
		exit;
	}
	
	function mysqli_pom($string){
		global $connection;
		
		$escape_string=mysqli_real_escape_string($connection,$string);
		return $escape_string;
	}

	function conform_query($result_set){
		if(!isset($result_set)){
			die("Database query faild.");
		}
	}
	
	function properties_buy(){
		global $connection;
		
		$query="SELECT properties_info.`id`,  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE type='buy'";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function top_properties_buy(){
		global $connection;
		
		$query="SELECT properties_info.`id`,  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE type='buy' ORDER BY date DESC LIMIT 0,3;";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function top_properties_rent(){
		global $connection;
		
		$query="SELECT properties_info.`id`,  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE type='rent' ORDER BY date DESC LIMIT 0,3;";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function properties_rent(){
		global $connection;
	
		$query="SELECT properties_info.`id`,  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE type='rent' and visible=1 ";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function properties_rent_id($rent_id){
		global $connection;
		$safe_rent_id=mysqli_real_escape_string($connection,$rent_id);
		
		$query="SELECT  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE visible=1 and properties_info.id={$safe_rent_id}";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function properties_buy_id($buy_id){
		global $connection;
		$safe_buy_id=mysqli_real_escape_string($connection,$buy_id);
		
		$query="SELECT  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE visible=1 and properties_info.id={$safe_buy_id}";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function properties_db_id($property_id){
		global $connection;
		$safe_property_id=mysqli_real_escape_string($connection,$property_id);
		
		$query="SELECT  properties_info.`id`,properties_info.`client_id`,
				properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE visible=1 and properties_info.id={$safe_property_id}";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function properties_db_id_visible($property_id){
		global $connection;
		$safe_property_id=mysqli_real_escape_string($connection,$property_id);
		
		$query="SELECT  properties_info.`id`,properties_info.`client_id`,
				properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE properties_info.id={$safe_property_id}";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	
	function properties_db(){
		global $connection;
		
		$query="SELECT * FROM properties_info;";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function comment_db($property_id){
		global $connection;
		$safe_property_id=mysqli_real_escape_string($connection,$property_id);
		
		$query="SELECT  * FROM comment WHERE property_id={$safe_property_id}";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function select_division(){
		global $connection;
		
		$query="SELECT * FROM division ";
		$district_result=mysqli_query($connection,$query);
		conform_query($district_result);	
		return $district_result;
	}
	
	function select_division_name($division_id){
		global $connection;
		$safe_division_id=mysqli_real_escape_string($connection,$division_id);
		
		$query ="SELECT * ";
		$query .="FROM division ";
		$query .="WHERE division_id={$safe_division_id}; ";
		$result=mysqli_query($connection,$query);
		conform_query($result);
		
			return null;
	}
	
	function select_district(){
		global $connection;
		
		$query="SELECT * FROM district";
		$district_result=mysqli_query($connection,$query);
		conform_query($district_result);	
		return $district_result;
	}
	
	function client_db(){
		global $connection;
		
		$query="SELECT * FROM client_info WHERE type='client' ";
		$result=mysqli_query($connection,$query);
		conform_query($result);	
		return $result;
	}
	
	function client_data($client_id){
		global $connection;
		$safe_client_id=mysqli_real_escape_string($connection,$client_id);
		
		$query ="SELECT * ";
		$query .="FROM client_info ";
		$query .="WHERE client_id='{$safe_client_id}' and type='client' ;";
		$result=mysqli_query($connection,$query);
		conform_query($result);
		return $result;
		
	}
	
	function client_properties($client_id){
		global $connection;
		$safe_client_id=mysqli_real_escape_string($connection,$client_id);
		
		$query="SELECT properties_info.`id`,  properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE client_id='{$safe_client_id}' ;";
		$result=mysqli_query($connection,$query);
		
		conform_query($result);
		return $result;
	}
	
	function client_properties_update($property_id){
		global $connection;
		$safe_property_id=mysqli_real_escape_string($connection,$property_id);
		$query="SELECT  properties_info.`id`, properties_info.`image`, properties_info.`division_id`,
				`division_name`, properties_info.`district_id`,district_name,`address`, `detail`, `price`, 
				`requirement`, `contact`, `type`, `date`, `visible` 
				FROM 
				properties_info INNER JOIN division INNER JOIN district 
				ON 
				properties_info.division_id = division.division_id    
				AND 
				properties_info.district_id = district.district_id 
				WHERE properties_info.id={$safe_property_id} LIMIT 1;";
		$result = mysqli_query($connection,$query);
		
		conform_query($result);
		return $result;
	}
	
	function comment_data($property_id){
		global $connection;
		$safe_property_id=mysqli_real_escape_string($connection,$property_id);
		$query="SELECT  * from comment where property_id={$safe_property_id} LIMIT 1;";
		$result=mysqli_query($connection,$query);
		
		conform_query($result);
		return $result;
	}
	
	function select_url(){
		global $select_client;
		global $select_property;
		
		if(isset($_GET['client_id'])){
			$select_client=$_GET['client'];
			$select_property=null;
		}
		elseif(isset($_GET['property_id'])){
			$select_client=null;
			$select_property=$_GET['property'];
		}
		else{
			$select_client=null;
			$select_property=null;
		}
	}
	
	
	function select_division_district(){
		global $select_division;
		global $select_district;
		
		if(isset($_GET['division'])){
			$select_division=$_GET['division'];
			$select_district=null;		
		}
		elseif(isset($_GET['district'])){
			$select_division=null;
			$select_district=$_GET['district'];
		}
		else{
			$select_division=null;
			$select_district=null;
		}
	}
	
	function form_errors($errors=array()){
	$output = " ";
	if(!empty($errors)){
		$output .= "<div class=\"errors\">";
		$output .= "Plz fix the errors.";
		$output .= "<ul>";
		foreach($errors as $key => $error){
			$output.= "<li>";
			$output.= htmlentities($error);
			$output.= "</li>";
		}
		$output .= "</ul>";
		$output .= "</div>";
	}
	
	return $output;
	}
	
	
	function client_email($email){
		global $connection;
		$safe_email=mysqli_real_escape_string($connection,$email);
		
		$query ="SELECT * ";
		$query .="FROM client_info ";
		$query .="WHERE email='{$safe_email}' ";
		$query .="LIMIT 1;";
		$result=mysqli_query($connection,$query);
		conform_query($result);
		
		if($subject=mysqli_fetch_assoc($result)){
			return $subject;
		}
		else{
			return null;
		}
	}
	
	function admin(){
		global $connection;
		
		$query ="SELECT * ";
		$query .="FROM client_info ";
		$query .="WHERE type='admin' ";
		$query .="LIMIT 1;";
		$result=mysqli_query($connection,$query);
		conform_query($result);
		
		return $result;
	}
	
	function conform_password($password,$repassword){
		$passwordok="";
		if($password==$repassword){
			$passwordok=$password;
		}else{
			exit();
		}
		return $passwordok;
	}
	
	function password_encrypt($password){
		$hash_format= "$2y$10$";
		$salt_length= 22;
		$salt= generate_salt($salt_length);
		$format_and_salt= $hash_format . $salt ;
		$hash= crypt($password,$format_and_salt);
		return $hash;
	}
	
	function generate_salt($length){
		$unique_random_string = md5(uniqid(mt_rand(),true));
		$base64_string = base64_encode($unique_random_string);
		$modified_base64_string = str_replace('+', '.', $base64_string);
		$salt=substr($modified_base64_string, 0, $length);
		return $salt;
	}
	
	function password_check($password, $existing_hash){
		$hash=crypt($password, $existing_hash);
		if($hash === $existing_hash){
			return true;
		}else{
			return false;
		}
	}
	
	function attempt_login($email,$password){
		$client=client_email($email);
		if($client){
			if(password_check($password, $client["password"])){
				return $client;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	function logged_in(){
		return isset($_SESSION['client_id']);
	}
	
	function conform_logged_in(){
		if(!logged_in()){
			redirection_page("login.php");	
		}
	}
	
	function admin_logged_in(){
		if($_SESSION['type']=='admin')
		return $_SESSION['type'];
	}
	
	function conform_admin_login(){
		if(!admin_logged_in()){
			redirection_page("login.php");	
		}
	}
?>