<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php conform_logged_in(); ?>
<?php include("include/layout/header_about.php"); ?>
<?php
	if(isset($_POST['upload'])){
		
		
	/********************************************************************************************************/
		$target_dir = "uploads/";


		$extension = array_pop(explode('.', basename($_FILES["fileToUpload"]["name"])));
		$extension=".".$extension;

		$target_file = $target_dir . time().$extension;
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		
		if (file_exists($target_file)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
	
		if ($_FILES["fileToUpload"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
	
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
	
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
			
		} 
		else {
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				$query = sprintf("UPDATE 
									properties_info
								  SET
								  	image = '%s'
								  WHERE
								  	id = %s",$target_file, $_POST['property_id']);
				
				$result=mysqli_query($connection,$query);
				if($result)
				{
					$_SESSION["message"]="Image uploaded Succesfully..";
					redirection_page(sprintf("user_profile.php?id=%s",$id));
				}
				else{
					$_SESSION["message"]="Information does not upload";
					redirection_page(sprintf("user_profile.php?id=%s",$id));
				}	
			} 
			else {
				echo "Sorry, there was an error uploading your file.";
			}
		}
	}
/*************************************************************************************************************/
?>
<!--
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Giving Addvertise of Buying/Renting Properties </h2>
		 <div class="grid_8">
			<form id="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data" >
			<input type="hidden" name="property_id" value="<?php echo $_GET['property_id']; ?>">
            <label><strong>Image:</strong><input type="file" name="fileToUpload" id="fileToUpload" value=""></label>
			<div class="btns">
			<input type="submit" class="button" name="upload" value="Submit"/>
			</div>
        </form> 
	</div>
	</div>
 </div>  
</section> 
<!--==============================footer=================================-->
 
<?php include("include/layout/footer_buy.php");?>