<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->
 <section id="content">
    <div class="container_12">	
      <div class="grid_8">
		
        <h2 class="p4">Propertie's Information:</h2>
       
		 <?php	
				$property_id=$_GET["property_id"];
				$client=  properties_db_id_visible($property_id);
				while($client_row=mysqli_fetch_assoc($client)){
			?>
		<div class="warp">	
        <img src="<?php echo htmlentities($client_row["image"]); ?>" alt="" class="img-border img-indent">
        <div class="extra-wrap">
        <p class="color-1 p6">
		Property ID:<?php echo htmlentities($client_row["id"]); ?><br/>
		Address:<?php echo htmlentities($client_row["address"]); ?><br/>
		Division:<?php echo htmlentities($client_row["division_name"]); ?><br/>
		District:<?php echo htmlentities($client_row["district_name"]); ?><br/>
		Details:<?php echo htmlentities($client_row["detail"]); ?><br/>
		Price:<?php echo htmlentities($client_row["price"]); ?><br/>
		Requirement:<?php echo htmlentities($client_row["requirement"]); ?><br/>
		Contact:<?php echo htmlentities($client_row["contact"]); ?><br/>
		Type:<?php echo htmlentities($client_row["type"]); ?><br/>
		Visibelity:<?php echo htmlentities($client_row["visible"]); ?><br/>
		Date:<?php echo htmlentities($client_row["date"]); ?><br/></p>
		<p>
			<a href="delete_property_id_admin.php?property_id=<?php echo urlencode($client_row[id]); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
		</p>
		
		<br/>
		
	</div>
 </div>
 <!----------------------------------COMMENT------------------------------------------------>		
	<div class="extra-warp">	
		<h3 class="top-1 p3">Comment</h3>
		<?php
			$comment_data= comment_db($client_row["id"]);
			while($comment_row=mysqli_fetch_assoc($comment_data)){
			?>
		Name:<?php echo htmlentities($comment_row["name"]); ?><br/>
		Contact:<?php echo htmlentities($comment_row["contact"]); ?><br/>
		Comment:<?php echo htmlentities($comment_row["comment"]); ?><br/>
		Date:<?php echo htmlentities($comment_row["date"]); ?><br/><br/>
		
		<p>
			<a href="delete_property_admin_comment.php?comment_id=<?php echo urlencode($comment_row[id]); ?>&&property_id=<?php echo urlencode($comment_row[property_id]); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
		</p>
		<?php }
			mysqli_free_result($comment_data);?><hr/>
		<?php }
			mysqli_free_result($client);?>
	</div>
<!------------------------------------------------------------------------------>	
    </div> 
   </div>
 <div class="clear"></div>
</section> 
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>