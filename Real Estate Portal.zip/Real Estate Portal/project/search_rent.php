<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_rent.php"); ?>
<!----------------------------------------------------------------------------------------->
	<section id="content">
		<div class="container_12">	
		  <div class="grid_8"><br/><br/>
<?php
	
	if(isset($_POST['search'])){
		
			$division_id=(int)($_POST["division_id"]);
			$district_id=(int)($_POST["district_id"]);
			$price=(int) $_POST["price"];
			//$type=mysqli_pom ($_POST["type"]);
			
			$query="SELECT * FROM properties_info WHERE
					division_id LIKE {$division_id} OR
					district_id LIKE {$district_id} OR
					price LIKE {$price} and
					type LIKE 'rent' and visible=1";
			
			$result=mysqli_query($connection,$query);
	
			if($result)
			{
				//$_SESSION["search_result"]=$result;
				while($rent_row=mysqli_fetch_assoc($result)){ 
				echo "<div class=\"wrap\">";
				echo "<img src=\"";
				echo htmlentities($rent_row["image"]); 
				echo "\" alt=\"\" class=\"img-border img-indent\">";
				echo "<div class=\"extra-wrap\">";
				echo "<p class=\"color-1 p6\">";
				echo "Address:";
				echo htmlentities($rent_row["address"]); 
				echo "<br/>";
				echo "Details:";
				echo htmlentities($rent_row["detail"]);
				echo "<br/>";
				echo "Price:";
				echo htmlentities($rent_row["price"]);
				echo "<br/>";
				echo "</div>";
				echo "</div>";
				echo "<p class=\"p5\">";
				echo "<a href=\"rent_view.php?id=";
				echo urlencode($rent_row["id"]); 
				echo "\" class=\"button\">Read More</a></p>";
		 }
		 mysqli_free_result($result);
		
			//redirection_page("buying.php");
			}
			else{
				$_SESSION["message"]="Cant find the property";
				redirection_page("renting.php");
			}
	}	
?>
<h2 class="top-1 p3">All Properties for Buy</h2>
        <p>For view all buy properties information follow the link...</p><br/>
		<p class="p5"><a href="renting_all.php" class="button">View</a></p>
      </div>
     
</section> 
<!--==============================footer=================================-->
  

<?php include("include/layout/footer_buy.php");?>