<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_buy.php"); ?>

<!--==============================content================================-->

	<section id="content">
		<div class="container_12">	
		  <div class="grid_8">
	  
        <h2 class="top-1 p3">Property List For Buy</h2>
        <p>Here, you get the properties as you wish...</p><br/>
		<h3 class="top-1 p3">Top Property List For Buy</h3><hr/>
		
		<?php
			$result=$_SESSION["search_result"];
			while($buy_row=mysqli_fetch_assoc($result)){ ?>
			<div class="wrap">
			<img src="<?php echo htmlentities($buy_row["image"]); ?>" alt="" class="img-border img-indent">
			<div class="extra-wrap">
			<p class="color-1 p6">
			Address:<?php echo htmlentities($buy_row["address"]); ?><br/>
			Division:<?php echo htmlentities($buy_row["division_name"]); ?><br/>
			District:<?php echo htmlentities($buy_row["district_name"]); ?><br/>
			Details:<?php echo htmlentities($buy_row["detail"]); ?><br/>
			Price:<?php echo htmlentities($buy_row["price"]); ?><br/>
			<p class="p5"><a href="buy_view.php?id=<?php echo urlencode($buy_row["id"]); ?>" class="button">Read More</a></p>
        </div>
        </div>
		<?php }
		 mysqli_free_result($result);
		 ?>
		 <hr/>
		
		<h2 class="top-1 p3">All Properties for Buy</h2>
        <p>For view all buy properties information follow the link...</p><br/>
		<p class="p5"><a href="buying_all.php" class="button">View</a></p>
      </div>
     
</section> 
 
<?php include("include/layout/footer_buy.php");?>