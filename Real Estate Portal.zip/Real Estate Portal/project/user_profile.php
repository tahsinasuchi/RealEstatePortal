<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php conform_logged_in(); ?>
<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Welcome <?php echo	htmlentities($_SESSION["user_name"]);?>!</h2>
        <p class="p2">You can view all your post. And also insert new post or update old post..</p>
         <div class="extra-wrap">
			<?php	
				$client_id=$_SESSION["client_id"];
				$client_id_info= client_data($client_id);
				while($client_info=mysqli_fetch_assoc($client_id_info)){
			?>
		
		<p class="color-1 p6">
		User Name:<?php echo htmlentities($client_info["user_name"]); ?><br/>
		First Name:<?php echo htmlentities($client_info["first_name"]); ?><br/>
		Last Name:<?php echo htmlentities($client_info["last_name"]); ?><br/>
		Email:<?php echo htmlentities($client_info["email"]); ?><br/>
		Contact:<?php echo htmlentities($client_info["contact"]); ?><br/>
		Client ID:<?php echo htmlentities($client_info["client_id"]); ?><br/>
		Address:<?php echo htmlentities($client_info["address"]); ?><br/></p>
			<?php }
				mysqli_free_result($client_id_info);?>
            </div>
		
		<p class="p2">For update your Profile ...</p>
		<p><a href="profile.php?client_id=<?php echo urlencode($client_id); ?>" class="button">View</a></p>
		 
	    <div class="extra-wrap">
			<p class="color-1 p6">
			For Insert new property...</p>
			<p>
			<a href="buy_property.php?client_id=<?php echo urlencode($client_id); ?>" class="button">Insert</a>
			</p>
        </div>
		 
        <h2 class="p4">Your Properties:</h2>
       
		 <?php	$client= client_properties($client_id);
					while($client_row=mysqli_fetch_assoc($client)){
			?>
		<div class="warp">	
        <img src="<?php echo htmlentities($client_row["image"]); ?>" alt="" class="img-border img-indent">
        <div class="extra-wrap">
        <p class="color-1 p6">
		Property ID:<?php echo htmlentities($client_row["id"]); ?><br/>
		Address:<?php echo htmlentities($client_row["address"]); ?><br/>
		Division:<?php echo htmlentities($client_row["division_name"]); ?><br/>
		District:<?php echo htmlentities($client_row["district_name"]); ?><br/>
		Details:<?php echo htmlentities($client_row["detail"]); ?><br/>
		Price:<?php echo htmlentities($client_row["price"]); ?><br/>
		Requirement:<?php echo htmlentities($client_row["requirement"]); ?><br/>
		Contact:<?php echo htmlentities($client_row["contact"]); ?><br/>
		Type:<?php echo htmlentities($client_row["type"]); ?><br/>
		Visibelity:<?php echo htmlentities($client_row["visible"]); ?><br/>
		Date:<?php echo htmlentities($client_row["date"]); ?><br/></p>
		<p>
			<a href="update_property.php?property_id=<?php echo urlencode($client_row[id]); ?>" class="button">Update</a>
		</p>
		<br/>
		<p>
			<a href="delete_property.php?property_id=<?php echo urlencode($client_row[id]); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
		</p><br/>
		<p>
			<a href="upload_property_photo.php?property_id=<?php echo urlencode($client_row[id]); ?>" class="button">Image Upload</a>
		</p>

	</div>
 </div>
 <!----------------------------------COMMENT------------------------------------------------>		
	<div class="extra-warp">	
		<h3 class="top-1 p3">Comment</h3>
		<?php
			$comment_data= comment_db($client_row["id"]);
			while($comment_row=mysqli_fetch_assoc($comment_data)){
			?>
		Name:<?php echo htmlentities($comment_row["name"]); ?><br/>
		Contact:<?php echo htmlentities($comment_row["contact"]); ?><br/>
		Comment:<?php echo htmlentities($comment_row["comment"]); ?><br/>
		Date:<?php echo htmlentities($comment_row["date"]); ?><br/><br/>
		
		<p>
			<a href="delete_comment.php?property_id=<?php echo urlencode($comment_row[id]); ?>" class="button" onclick="return confirm('Are you sure to Delete?');">Delete</a>
		</p>
		<?php }
			mysqli_free_result($comment_data);?><hr/>	
		<?php }
			mysqli_free_result($client);?>
	</div>
<!------------------------------------------------------------------------------>	
    </div> 
   </div>
 <div class="clear"></div>
</section> 
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>