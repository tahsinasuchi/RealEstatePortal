<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php include("include/layout/header_about.php"); ?>

<?php $id=$_GET["property_id"];?>
<?php
	if(isset($_POST['update'])){
		$visible=(int) $_POST["visible"];
		$id=$_POST["id"];
		$query=sprintf("UPDATE  properties_info SET  
					 visible = %s
					WHERE  id = %s LIMIT 1",
					$visible,$id);
			
		$result=mysqli_query($connection,$query);
	
		if($result)
			{
				//$_SESSION["message"]="Successfuly Product Deleted..";
				redirection_page("properties_info.php");
			}
		else{
				//$message="Product Does Not Deleted..";
				redirection_page("properties_info.php");
			}
	}else{
	}
			
?>

<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <p class="p2">You can view and update your profile..</p>
		
		<h2 class="p4">Your Information:</h2>
		<?php echo message(); 
			  echo form_errors($errors);
			  ?>
		
		<div class="wrap block-1">
			<?php
				$property=  properties_db_id_visible($id);
				while($property_row=mysqli_fetch_assoc($property)){
			?>
			
        <form id="form" action="update_property_id_admin.php?property=<?php echo urlencode($property_row["id"]); ?>" method="post" >
				
			<input type="hidden" name="id" value="<?php echo htmlentities($property_row["id"]); ?>">
			<label><strong>Visiblity:</strong></label>
				<input type="radio" name="visible" value="1" 
				<?php if($property_row[visible]==1){ echo "checked";} ?>/>Visible<br/>
				<input type="radio" name="visible" value="0" 
				<?php if($property_row[visible]==0){ echo "checked";} ?>/>Not Visible<br/><br/>
			
			<?php }
				mysqli_free_result($property);?>
			<input type="submit" name="update" value="Update" class="sbtn-1" >	
            
        </form> 
        </div>
      </div>
      
      <div class="clear"></div>
    </div>  
</section> 
</div>    

<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>