Cufon.replace('.social-icons span, h2, h3, .button', { fontFamily: 'Vegur', hover:true});
Cufon.replace('ul.menu li a', { fontFamily: 'Vegur_bold', hover:true});
