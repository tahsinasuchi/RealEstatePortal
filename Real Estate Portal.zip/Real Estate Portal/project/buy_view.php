<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_buy.php"); ?>

<!--==============================content================================-->
<?php $buy_id=$_GET["id"]; ?>
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
	  <div class="wrap">
        <h2 class="top-1 p3">Property List For Buy</h2>
        <p>Here, you get the properties as you wish...</p><br/><br/><br/>
		
		<?php
			$buy= properties_buy_id($buy_id);
			while($buy_row=mysqli_fetch_assoc($buy)){
			?>
		
        <img src="<?php echo htmlentities($buy_row["image"]); ?>" alt="" class="img-border img-indent">
        <div class="extra-wrap">
        <p class="color-1 p6">
		Address:<?php echo htmlentities($buy_row["address"]); ?><br/>
		Division:<?php echo htmlentities($buy_row["division_name"]); ?><br/>
		District:<?php echo htmlentities($buy_row["district_name"]); ?><br/>
		Details:<?php echo htmlentities($buy_row["detail"]); ?><br/>
		Price:<?php echo htmlentities($buy_row["price"]); ?><br/>
		Requirement:<?php echo htmlentities($buy_row["requirement"]); ?><br/>
		Contact:<?php echo htmlentities($buy_row["contact"]); ?><br/>
		Date:<?php echo htmlentities($buy_row["date"]); ?><br/></p>
       
		<?php }
		    mysqli_free_result($buy);?>	
		<hr/>
		 </div>
        </div>
<!----------------------------------COMMENT------------------------------------------------>		
	<div class="wrap">
		<h3 class="top-1 p3">Comment</h3>
		<?php
			$comment_data= comment_db($buy_id);
			while($comment_row=mysqli_fetch_assoc($comment_data)){
			?>
		Name:<?php echo htmlentities($comment_row["name"]); ?><br/>
		Contact:<?php echo htmlentities($comment_row["contact"]); ?><br/>
		Comment:<?php echo htmlentities($comment_row["comment"]); ?><br/>
		Date:<?php echo htmlentities($comment_row["date"]); ?><br/><br/>
		<hr />
		<?php }
			mysqli_free_result($comment_data);?>	
		
        <p>For comment on this property add follow the link...</p><br/>
		<p class="p5"><a href="comment_buy.php?property_id=<?php echo urlencode($buy_id); ?>" class="button">Comment</a></p>
      
	  <?php echo message(); ?>
	  <?php echo form_errors($errors);?>
	 </div>
	  </div>
<!----------------------------------SEARCH------------------------------------------------>	  
      <div class="grid_4">
        <div class="left-1">
		
            <h2 class="top-1 p3">Find your Property</h2>
            <form id="form-1" action="search_buy.php" method="post" class="form-1 bot-2">
                  <div class="select-1">
                   <label>Division:</label>
					<select name="division_id">
					<?php	$division= select_division();?>
					<?php while($division_row=mysqli_fetch_assoc($division)){?>
					<option value="<?php echo ($division_row["division_id"]); ?>">
					<?php echo htmlentities($division_row["division_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($division);?>
					</select>  
                </div>
				<div class="select-1">
					<label>District:</label>
					<select name="district_id">
					<?php	$district= select_district();?>
					<?php while($district_row=mysqli_fetch_assoc($district)){?>
					<option value="<?php echo ($district_row["district_id"]); ?>">
					<?php echo htmlentities($district_row["district_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($district);?>
					</select>
			   </div>
                <div class="select-1">
                    <label>Price</label>
                     <select name="price">
					<?php	$properties= properties_db();?>
					<?php while($properties_row=mysqli_fetch_assoc($properties)){?>
					<option value="<?php echo ($properties_row["price"]); ?>">
					<?php echo htmlentities($properties_row["price"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($properties);?>
					</select> 
                </div> 
				<br/>
                <div>
					<input type="submit" class="submit" name="search" value="Search"/>
				</div>
				<div class="clear"></div>
            </form>
            <h2 class="p3">Best offers</h2>
            <p class="color-1">Eid Offer!Summer Offer!!Winter Offer!!! </p><br/>
            <p></p>
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
 
<?php include("include/layout/footer_buy.php");?>