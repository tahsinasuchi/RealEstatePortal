<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Giving Addvertise of Buying/Renting Properties </h2>
        <div class="wrap">
        	<img src="images/page5-img1.jpg" alt="" class="img-border img-indent">
            <div class="extra-wrap">
            	<p class="color-1 p6">Here,
									 anyone can give property addvertise for selling or renting.</p>
           		<p>For giving property addvertise, you have to registry
			       in our site first and then you can give your add.</p>
            </div>
        </div>
        <p class="p5">For giving addvertise about your 
				   property, you have to give valid information other wise we will sue you. 
				   First you have to registry to our site, then you can post your property advertise.</p>
       <!-- <a href="buy_property.php" class="button">Read More</a>-->
		
        <h2 class="top-2 p3"> Buying/Renting Properties </h2>
        <div class="wrap">
        	<img src="images/page5-img2.jpg" alt="" class="img-border img-indent">
            <div class="extra-wrap">
            	<p class="color-1 p6">Here,
									anyone can buy or rent their property as they wish 
									 </p>
           		<p>For renting property, you can visit our site and choose property 
				   which is switable for you.</p>
            </div>
        </div>
        <p class="p5">You can get property for buy/rent as you wish.</p>
        <!--<a href="#" class="button">Read more</a>-->
      </div>
	  <br/><br/>
      <div class="grid_4">
        <div class="left-1">
            <h2 class="p3">Our contacts</h2>
            <dl>
                <dt class="color-1 p2"><strong>Rajshahi University,<br>Rajshahi.</strong></dt>
                <dd><span>Freephone:</span>+881XXXXXXXXX</dd>
                <dd><span>Telephone:</span>+8802XXXXXX</dd>
                <dd><span>E-mail:</span><a href="#" class="link">mail@live.com</a></dd>
            </dl>
			<br/><br/>
            <h2 class="p3">User Profile</h2>
            <p class="color-1 p6"><strong>
				If anyone interested then registry in 
				our site and can give their property 
				addvertise.Our client can insert or 
				update their profile and also their addvertise.
			</strong></p>
            <p><a href="user_profile.php" class="button">Read more</a></p></br>
			
			<h2 class="p3">Admin Profile</h2>
            <p class="color-1 p6"><strong>
				Only Admin can access.
			</strong></p>
            <p><a href="admin_profile.php" class="button">Read more</a></p>
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>