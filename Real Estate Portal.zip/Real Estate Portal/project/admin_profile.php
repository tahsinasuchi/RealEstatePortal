<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>
<?php	conform_admin_login(); ?>
<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
        <h2 class="top-1 p3">Client Information</h2>
        <div class="wrap">
            <div class="extra-wrap">
            	<p class="color-1 p6">
					You can view all client's information and their peroperty information.
				</p>
           		<p>To view all client's information follow the link...</p>
            </div>
        </div>
        <a href="client_info.php" class="button">Read More</a>
		
        <h2 class="top-2 p3">Properties Information</h2>
        <div class="wrap">
            <div class="extra-wrap">
            	<p class="color-1 p6">
				You can view all peroperty information.
				</p>
           	</div>
        </div>
        <p class="p5">Follow the link...</p>
        <a href="properties_info.php" class="button">Read more</a>
      </div>
	  <br/><br/>
      <div class="grid_4">
        <div class="left-1">
            <h2 class="p3">Our contacts</h2>
            <dl>
                <dt class="color-1 p2"><strong>Rajshahi University,<br>Rajshahi.</strong></dt>
                <dd><span>Freephone:</span>+881XXXXXXXXX</dd>
                <dd><span>Telephone:</span>+8802XXXXXX</dd>
                <dd><span>E-mail:</span><a href="#" class="link">mail@live.com</a></dd>
            </dl>
			<br/><br/>
           
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>