<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_buy.php"); ?>

<!-----------------------------Comment Post-------------------------------->
<?php $property_id=$_GET["property_id"]; ?>
<?php
	if(isset($_POST['comment_submit'])){
		
		$requried_fields = array("name","contact","comment");
		validation_presence($requried_fields);
		
		$fields_with_max_length=array(name=>80,contact=>15);
		validation_length($fields_with_max_length);
		
		if(empty($errors)){
			$id=(int)($_POST["id"]);
			$name=mysqli_pom($_POST["name"]);
			$contact=mysqli_pom($_POST["contact"]);
			$comment=mysqli_pom($_POST["comment"]);
			
			$query="INSERT INTO comment
					(property_id, name,contact,comment)
					VALUES({$id},'{$name}','{$contact}','{$comment}');";
			
			$result=mysqli_query($connection,$query);
	
			if($result)
			{
				$_SESSION["message"]="Comment Inserted Succesfully..";
				redirection_page("buy_view.php");
			}
			else{
				$_SESSION["message"]="comment does not inserted";
				redirection_page("comment_box.php");
			}	
		}
		}
		else{
			
			}	
?>
<!--==============================content================================-->

<section id="content">
    <div class="container_12">	
      <div class="grid_8">
		<h2 class="top-1 p3">Comment</h2>
		<?php 
			$property_id=$_GET["property_id"];
		?>
        <form id="form" action="comment_box.php" method="post" >
			<label><strong>Property ID:</strong><input type="text" name="id" value="<?php echo($property_id)?>"></label>
			<label><strong>Name:</strong><input type="text" name="name" value=""></label>
			<label><strong>Contact:</strong><input type="text" name="contact" value=""></label>
			<label><strong>Comment:</strong><textarea name="comment"></textarea></label>
			<input type="submit" class="button" name="comment_submit" value="Comment"/>
		</form>
      </div>
	
<!----------------------------------SEARCH------------------------------------------------>	  
      <div class="grid_4">
        <div class="left-1">
		
            <h2 class="top-1 p3">Find your Property</h2>
            <form id="form-1" class="form-1 bot-2">
                <div class="select-1">
                    <label>Property type</label>
                    <select name="select" >
                        <option>Property for sale</option>
                    </select>   
                </div>
                <div>
                    <label>Location</label>
                    <input type="text" value="Address, City, Zip" onBlur="if(this.value=='') this.value='Address, City, Zip'" onFocus="if(this.value =='Address, City, Zip' ) this.value=''"  />
                </div>
                <div class="select-2">
                    <label>Size</label>
                   <select name="select" >
                        <option>&nbsp;</option>
                    </select> 
                </div>
                <div class="select-2 last">
                    <label>Price</label>
                   <select name="select" >
                        <option>&nbsp;</option>
                    </select>  
                </div> <br/>
                <a onClick="document.getElementById('form-1').submit()" class="button">Search</a>
                <div class="clear"></div>
            </form>
            
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
 
<?php include("include/layout/footer_buy.php");?>