<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_rent.php"); ?>

<!--==============================content================================-->
<section id="content">
    <div class="container_12">	
      <div class="grid_8">
         <h2 class="top-1 p3">Property List For Rent</h2>
        <p>Here, you get the properties as you wish...</p><br/><br/><br/>
		
		<?php	$rent= properties_rent();?>
		<?php while($rent_row=mysqli_fetch_assoc($rent)){?>
	
		<div class="wrap">
        	<img src="<?php echo htmlentities($rent_row["image"]); ?>" alt="" class="img-border img-indent">
            <div class="extra-wrap">
            	<p class="color-1 p6">Address:<?php echo htmlentities($rent_row["address"]); ?><br/>
		Division:<?php echo htmlentities($rent_row["division_name"]); ?><br/>
		District:<?php echo htmlentities($rent_row["district_name"]); ?><br/>
		Details:<?php echo htmlentities($rent_row["detail"]); ?><br/>
		Price:<?php echo htmlentities($rent_row["price"]); ?><br/>
	
		<p class="p5"><a href="rent_view.php?id=<?php echo urlencode($rent_row["id"]); ?>" class="button">Read More</a></p>
            </div>
        </div>
		
		<hr/>
		<?php }?>
		<?php mysqli_free_result($rent);?>
	
      </div>
      <div class="grid_4">
        <div class="left-1">
            <h2 class="top-1 p3">Find your Home</h2>
            <form id="form-1"  action="search_rent.php" method="post" class="form-1 bot-2">
                <div class="select-1">
                   <label>Division:</label>
					<select name="division_id">
					<?php	$division= select_division();?>
					<?php while($division_row=mysqli_fetch_assoc($division)){?>
					<option value="<?php echo ($division_row["division_id"]); ?>">
					<?php echo htmlentities($division_row["division_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($division);?>
					</select>  
                </div>
				<div class="select-1">
					<label>District:</label>
					<select name="district_id">
					<?php	$district= select_district();?>
					<?php while($district_row=mysqli_fetch_assoc($district)){?>
					<option value="<?php echo ($district_row["district_id"]); ?>">
					<?php echo htmlentities($district_row["district_name"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($district);?>
					</select>
			    </div>
                <div class="select-1">
                    <label>Price</label>
                     <select name="price">
					<?php	$properties= properties_db();?>
					<?php while($properties_row=mysqli_fetch_assoc($properties)){?>
					<option value="<?php echo ($properties_row["price"]); ?>">
					<?php echo htmlentities($properties_row["price"]); ?>
					</option>
					<?php } ?>
					<?php mysqli_free_result($properties);?>
					</select> 
                </div> 
				<br/>
                <div>
					<input type="submit" class="submit" name="search" value="Search"/>
				</div>
				<div class="clear"></div>
            </form>
            <h2 class="p3">Our guarantees</h2>
            <p class="color-1 p2">You can get you chooesable property as you wish.</p>
           
        </div>
      </div>
      <div class="clear"></div>
    </div>  
</section> 
</div>    
<!--==============================footer=================================-->
 
<?php include("include/layout/footer_buy.php");?>