<?php ob_start(); ?>
<?php require_once("include/session.php"); ?>
<?php require_once("include/function.php"); ?>

<?php 
	$_SESSION["client_id"]=null;
	$_SESSION["user_name"]=null;
	$_SESSION["email"]=null;
	redirection_page("login.php");			
?>
