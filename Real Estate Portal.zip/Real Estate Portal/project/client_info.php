<?php require_once("include/session.php"); ?>
<?php require_once("include/db_connection.php"); ?>
<?php require_once("include/function.php"); ?>
<?php require_once("include/validation_function.php"); ?>

<?php include("include/layout/header_about.php"); ?>
<!--==============================content================================-->

<section id="content">
    <div class="container_12">	
      <div class="grid_8">
	  
        <h2 class="top-1 p3">Client's Information</h2>
        <p>Here, you get all client's information...</p><br/>
		
		<table>
		<tr><th>Client ID</th><th>User Name</th><th>Contact</th><th>More</th></tr><br/>
		<?php	$client= client_db();?>
		<?php while($client_row=mysqli_fetch_assoc($client)){?>
		
		<tr>
		<td><?php echo htmlentities($client_row["client_id"]); ?></td>
		<td><?php echo htmlentities($client_row["user_name"]); ?></td>
		<td><?php echo htmlentities($client_row["contact"]); ?></td>
		<td><p class="p5"><a href="client_all_info.php?client_id=<?php echo urlencode($client_row["client_id"]); ?>" class="button">Read More</a>
		</p></td>
		</tr><br/>
		<?php }
		 mysqli_free_result($client);?>
		</table>
        
	</div>
	<br/><br/><br/>
  </div>
<div class="clear"></div>
</section> 
<!--==============================footer=================================-->
 <?php include("include/layout/footer_buy.php");?>